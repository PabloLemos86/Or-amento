import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { OFFICE_NAME } from '../constants/office';

export default function Header(){
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{OFFICE_NAME}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{ padding:14, backgroundColor:'#0f1724' , borderBottomWidth:1, borderBottomColor:'#1f2937'},
  title:{ color:'#e6eef8', fontSize:18, fontWeight:'700', textAlign:'center' }
});
