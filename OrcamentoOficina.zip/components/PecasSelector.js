import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Checkbox from 'expo-checkbox';

export const ALL_PECAS = [
  'Paralama direito','Paralama esquerdo','Teto',
  'Porta dianteira esquerda','Porta dianteira direita',
  'Porta traseira esquerda','Porta traseira direita',
  'Lateral traseira esquerda','Lateral traseira direita',
  'Tampa','Para-choque dianteiro','Para-choque traseiro',
  'Caixa de ar direita','Caixa de ar esquerda'
];

export default function PecasSelector({ selecionadas, togglePeca }){
  return (
    <View>
      {ALL_PECAS.map((p,i)=>(
        <View key={i} style={styles.row}>
          <Checkbox value={selecionadas.includes(p)} onValueChange={()=>togglePeca(p)} />
          <Text style={styles.label}>{p}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row:{ flexDirection:'row', alignItems:'center', marginVertical:8 },
  label:{ color:'#e6eef8', marginLeft:10 }
});
