import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './screens/HomeScreen';
import PecasScreen from './screens/PecasScreen';
import SubstituicaoScreen from './screens/SubstituicaoScreen';
import RecuperacaoScreen from './screens/RecuperacaoScreen';
import ValoresScreen from './screens/ValoresScreen';
import ResultadoScreen from './screens/ResultadoScreen';

const Stack = createNativeStackNavigator();

export default function App(){
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home" screenOptions={{headerShown:false}}>
        <Stack.Screen name="Home" component={HomeScreen}/>
        <Stack.Screen name="Pecas" component={PecasScreen}/>
        <Stack.Screen name="Substituicao" component={SubstituicaoScreen}/>
        <Stack.Screen name="Recuperacao" component={RecuperacaoScreen}/>
        <Stack.Screen name="Valores" component={ValoresScreen}/>
        <Stack.Screen name="Resultado" component={ResultadoScreen}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
