export const OFFICE_NAME = 'Oficina Teste';
export const DEFAULT_CURRENCY = 'R$';
