import * as Print from 'expo-print';
import { OFFICE_NAME, DEFAULT_CURRENCY } from '../constants/office';

export async function gerarPdf(orcamento){
  const rows = (arr)=> arr && arr.length ? arr.map(r=>`<tr><td>${r}</td></tr>`).join('') : '<tr><td>-</td></tr>';
  const html = `
  <html>
  <head>
    <meta charset="utf-8"/>
    <style>
      body{ font-family: Arial, Helvetica, sans-serif; color:#111; padding:20px;}
      .header{ text-align:center; margin-bottom:16px;}
      table{ width:100%; border-collapse:collapse; margin-top:8px;}
      th,td{ border:1px solid #ddd; padding:8px; text-align:left;}
      .totals{ margin-top:12px; font-weight:700; }
    </style>
  </head>
  <body>
    <div class="header">
      <h2>${OFFICE_NAME}</h2>
      <div>Orçamento de Lanternagem e Pintura</div>
    </div>

    <div><strong>Veículo:</strong> ${orcamento.carro} — ${orcamento.placa} — ${orcamento.ano}</div>
    <div><strong>Proprietário:</strong> ${orcamento.proprietario}</div>

    <h3>Peças (detalhamento)</h3>
    <table>
      <thead><tr><th>Peças pintadas</th></tr></thead>
      <tbody>${rows(orcamento.pecasPintadas)}</tbody>
    </table>

    <table>
      <thead><tr><th>Peças substituídas</th></tr></thead>
      <tbody>${rows(orcamento.pecasSubstituidas)}</tbody>
    </table>

    <table>
      <thead><tr><th>Peças recuperadas</th></tr></thead>
      <tbody>${rows(orcamento.pecasRecuperadas)}</tbody>
    </table>

    <div class="totals">
      <div>Lanternagem: ${DEFAULT_CURRENCY} ${Number(orcamento.valorLanternagem).toFixed(2)}</div>
      <div>Pintura: ${DEFAULT_CURRENCY} ${Number(orcamento.valorPintura).toFixed(2)}</div>
      <div>Total: ${DEFAULT_CURRENCY} ${Number(orcamento.valorTotal).toFixed(2)}</div>
    </div>
  </body>
  </html>
  `;
  return await Print.printAsync({ html });
}
