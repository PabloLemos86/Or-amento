
# OrcamentoOficina (Expo)

Projeto de teste: aplicativo de orçamentos para lanternagem e pintura.

Execução rápida (no celular):
1. Importe no Expo Snack (https://snack.expo.dev/) via GitHub ou copie os arquivos.
2. Abra no Expo Go para testar.

Este zip contém um app offline (sem autenticação). PDF gerado com expo-print.

