import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import Header from '../components/Header';
import PecasSelector from '../components/PecasSelector';

export default function PecasScreen({ route, navigation }){
  const { carro,placa,ano,proprietario } = route.params;
  const [selecionadas, setSelecionadas] = useState([]);

  const togglePeca = (p) => setSelecionadas(prev => prev.includes(p) ? prev.filter(x=>x!==p) : [...prev,p]);

  return (
    <ScrollView style={styles.container}>
      <Header />
      <View style={styles.inner}>
        <Text style={styles.title}>Selecione as peças que serão pintadas</Text>
        <PecasSelector selecionadas={selecionadas} togglePeca={togglePeca} />
        <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate('Substituicao',{carro,placa,ano,proprietario,pecasPintadas:selecionadas})}>
          <Text style={styles.buttonText}>Próximo: Substituição</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ backgroundColor:'#0b1220', flex:1 },
  inner:{ padding:16 },
  title:{ color:'#e6eef8', fontWeight:'700', marginBottom:12 },
  button:{ marginTop:18, backgroundColor:'#ff7a18', padding:12, borderRadius:10, alignItems:'center' },
  buttonText:{ color:'#08111a', fontWeight:'700' }
});
