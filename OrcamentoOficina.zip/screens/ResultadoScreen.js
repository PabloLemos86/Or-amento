import React from 'react';
import { View, Text, ScrollView, TouchableOpacity, Alert, StyleSheet } from 'react-native';
import Header from '../components/Header';
import { gerarPdf } from '../utils/pdf';

export default function ResultadoScreen({ route }){
  const { carro,placa,ano,proprietario,pecasPintadas,pecasSubstituidas,pecasRecuperadas,valorLanternagem,valorPintura } = route.params;
  const valorTotal = Number(valorLanternagem || 0) + Number(valorPintura || 0);
  const orcamento = { carro,placa,ano,proprietario,pecasPintadas,pecasSubstituidas,pecasRecuperadas, valorLanternagem, valorPintura, valorTotal };

  const onGerar = async ()=>{
    try{ await gerarPdf(orcamento); }
    catch(e){ Alert.alert('Erro','Não foi possível gerar o PDF: '+ (e.message||e)); }
  };

  return (
    <ScrollView style={styles.container}>
      <Header />
      <View style={styles.inner}>
        <Text style={styles.title}>Resumo do Orçamento</Text>
        <Text style={styles.row}><Text style={styles.bold}>Veículo: </Text>{carro} — {placa} — {ano}</Text>
        <Text style={styles.row}><Text style={styles.bold}>Proprietário: </Text>{proprietario}</Text>

        <Text style={styles.section}><Text style={styles.bold}>Peças pintadas:</Text> {pecasPintadas.join(', ') || '-'}</Text>
        <Text style={styles.section}><Text style={styles.bold}>Peças substituídas:</Text> {pecasSubstituidas.join(', ') || '-'}</Text>
        <Text style={styles.section}><Text style={styles.bold}>Peças recuperadas:</Text> {pecasRecuperadas.join(', ') || '-'}</Text>

        <View style={{marginTop:12}}>
          <Text style={styles.row}><Text style={styles.bold}>Lanternagem: </Text>R$ {Number(valorLanternagem).toFixed(2)}</Text>
          <Text style={styles.row}><Text style={styles.bold}>Pintura: </Text>R$ {Number(valorPintura).toFixed(2)}</Text>
          <Text style={[styles.row, {marginTop:6}]}><Text style={styles.bold}>Total: </Text>R$ {Number(valorTotal).toFixed(2)}</Text>
        </View>

        <TouchableOpacity style={styles.button} onPress={onGerar}>
          <Text style={styles.buttonText}>Gerar PDF</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ backgroundColor:'#0b1220', flex:1 },
  inner:{ padding:16 },
  title:{ color:'#e6eef8', fontWeight:'700', fontSize:18 },
  row:{ color:'#e6eef8', marginTop:8 },
  bold:{ fontWeight:'700', color:'#e6eef8' },
  section:{ color:'#cbd5e1', marginTop:10 },
  button:{ marginTop:18, backgroundColor:'#ff7a18', padding:12, borderRadius:10, alignItems:'center' },
  buttonText:{ color:'#08111a', fontWeight:'700' }
});
