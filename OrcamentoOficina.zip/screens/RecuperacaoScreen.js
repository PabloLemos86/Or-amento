import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import Header from '../components/Header';
import Checkbox from 'expo-checkbox';

export default function RecuperacaoScreen({ route, navigation }){
  const { carro,placa,ano,proprietario,pecasPintadas,pecasSubstituidas } = route.params;
  const possiveis = pecasPintadas.filter(p => !pecasSubstituidas.includes(p));
  const [recuperadas, setRecuperadas] = useState([]);

  const toggle = (p)=> setRecuperadas(prev => prev.includes(p) ? prev.filter(x=>x!==p) : [...prev,p]);

  return (
    <ScrollView style={styles.container}>
      <Header />
      <View style={styles.inner}>
        <Text style={styles.title}>Quais peças serão recuperadas?</Text>
        {possiveis.length===0 && <Text style={styles.note}>Não há peças elegíveis para recuperação.</Text>}
        {possiveis.map((p,i)=>(
          <View key={i} style={styles.row}>
            <Checkbox value={recuperadas.includes(p)} onValueChange={()=>toggle(p)} />
            <Text style={styles.label}>{p}</Text>
          </View>
        ))}

        <TouchableOpacity style={styles.button} onPress={()=>navigation.navigate('Valores',{carro,placa,ano,proprietario,pecasPintadas,pecasSubstituidas,pecasRecuperadas:recuperadas})}>
          <Text style={styles.buttonText}>Próximo: Valores</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ backgroundColor:'#0b1220', flex:1 },
  inner:{ padding:16 },
  title:{ color:'#e6eef8', fontWeight:'700', marginBottom:12 },
  note:{ color:'#94a3b8' },
  row:{ flexDirection:'row', alignItems:'center', marginVertical:8 },
  label:{ color:'#e6eef8', marginLeft:10 },
  button:{ marginTop:18, backgroundColor:'#ff7a18', padding:12, borderRadius:10, alignItems:'center' },
  buttonText:{ color:'#08111a', fontWeight:'700' }
});
