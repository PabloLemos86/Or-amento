import React, { useState } from 'react';
import { View, Text, TextInput, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import Header from '../components/Header';

export default function ValoresScreen({ route, navigation }){
  const { carro,placa,ano,proprietario,pecasPintadas,pecasSubstituidas,pecasRecuperadas } = route.params;
  const [lanternagem, setLanternagem] = useState('0');
  const [pintura, setPintura] = useState('0');

  const parse=(v)=>{ const n=parseFloat(String(v).replace(',','.')); return isNaN(n)?0:n; };

  return (
    <ScrollView style={styles.container}>
      <Header />
      <View style={styles.inner}>
        <Text style={styles.label}>Valor da lanternagem (R$)</Text>
        <TextInput style={styles.input} keyboardType="numeric" value={lanternagem} onChangeText={setLanternagem} />

        <Text style={styles.label}>Valor da pintura (R$)</Text>
        <TextInput style={styles.input} keyboardType="numeric" value={pintura} onChangeText={setPintura} />

        <TouchableOpacity style={styles.button} onPress={()=>{
          const vlLan=parse(lanternagem); const vlPin=parse(pintura);
          navigation.navigate('Resultado',{ carro,placa,ano,proprietario,pecasPintadas,pecasSubstituidas,pecasRecuperadas, valorLanternagem:vlLan, valorPintura:vlPin});
        }}>
          <Text style={styles.buttonText}>Gerar orçamento</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ backgroundColor:'#0b1220', flex:1 },
  inner:{ padding:16 },
  label:{ color:'#cbd5e1', marginTop:12, fontWeight:'600' },
  input:{ backgroundColor:'#071025', color:'#e6eef8', padding:10, borderRadius:8, borderWidth:1, borderColor:'#122034', marginTop:6 },
  button:{ marginTop:18, backgroundColor:'#ff7a18', padding:12, borderRadius:10, alignItems:'center' },
  buttonText:{ color:'#08111a', fontWeight:'700' }
});
