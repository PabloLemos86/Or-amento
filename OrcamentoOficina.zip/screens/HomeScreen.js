import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import Header from '../components/Header';

export default function HomeScreen({ navigation }){
  const [carro,setCarro]=useState('');
  const [placa,setPlaca]=useState('');
  const [ano,setAno]=useState('');
  const [proprietario,setProprietario]=useState('');

  const canContinue = carro.trim() && placa.trim() && proprietario.trim();

  return (
    <ScrollView style={styles.container} contentContainerStyle={{paddingBottom:40}}>
      <Header />
      <View style={styles.inner}>
        <Text style={styles.label}>Nome do carro</Text>
        <TextInput style={styles.input} value={carro} onChangeText={setCarro} placeholder="Ex: Fiat Uno" placeholderTextColor="#94a3b8" />
        <Text style={styles.label}>Placa</Text>
        <TextInput style={styles.input} value={placa} onChangeText={setPlaca} placeholder="ABC1D23" placeholderTextColor="#94a3b8" />
        <Text style={styles.label}>Ano</Text>
        <TextInput style={styles.input} value={ano} onChangeText={setAno} keyboardType="numeric" placeholder="2020" placeholderTextColor="#94a3b8" />
        <Text style={styles.label}>Proprietário</Text>
        <TextInput style={styles.input} value={proprietario} onChangeText={setProprietario} placeholder="Nome do cliente" placeholderTextColor="#94a3b8" />

        <TouchableOpacity style={[styles.button, !canContinue && styles.buttonDisabled]} disabled={!canContinue} onPress={()=>navigation.navigate('Pecas',{carro,placa,ano,proprietario})}>
          <Text style={styles.buttonText}>Próximo: Peças</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ backgroundColor:'#0b1220', flex:1 },
  inner:{ padding:16 },
  label:{ color:'#cbd5e1', marginTop:12, fontWeight:'600' },
  input:{ backgroundColor:'#071025', color:'#e6eef8', padding:10, borderRadius:8, borderWidth:1, borderColor:'#122034', marginTop:6 },
  button:{ marginTop:18, backgroundColor:'#ff7a18', padding:12, borderRadius:10, alignItems:'center' },
  buttonDisabled:{ opacity:0.6 },
  buttonText:{ color:'#08111a', fontWeight:'700' }
});
